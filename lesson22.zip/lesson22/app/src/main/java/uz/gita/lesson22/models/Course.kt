package uz.gita.lesson22.models

import android.content.ContentValues
import java.io.Serializable

data class Course(var id:Int,var image:Int, var name:String):Serializable
